/*
**************************************
* formatCurrency Function v1.1       *
* Autor: Carlos R. L. Rodrigues      *
**************************************
*/

//========================================================
// REQUIRES http://www.jsfromhell.com/geral/event-listener
//========================================================

function formatCurrency(o, n, dig, dec){
	o.c = !isNaN(n) ? Math.abs(n) : 2;
	o.dec = typeof dec != "string" ? "," : dec, o.dig = typeof dig != "string" ? "." : dig;
	addEvent(o, "keypress", function(e){
		if(e.key > 47 && e.key < 58){
			var o, s, l = (s = ((o = this).value.replace(/^0+/g, "") + String.fromCharCode(e.key)).replace(/\D/g, "")).length, n;
			if(o.maxLength + 1 && l >= o.maxLength) return false;
			l <= (n = o.c) && (s = new Array(n - l + 2).join("0") + s);
			for(var i = (l = (s = s.split("")).length) - n; (i -= 3) > 0; s[i - 1] += o.dig);
			n && n < l && (s[l - ++n] += o.dec);
			o.value = s.join("");
		}
		e.key > 30 && e.preventDefault();
	});
}